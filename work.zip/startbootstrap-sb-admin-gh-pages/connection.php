<?php
$mysqli= new mysqli("localhost","root","","doctors");
?>
