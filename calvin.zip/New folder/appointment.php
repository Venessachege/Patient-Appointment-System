<?php
include_once('connection.php');
$query="select * from appointments ";
$result=mysqli_query($mysqli,$query);
?>
<?php  
	while($rows = mysqli_fetch_assoc($result)){
  
   //echo "$firstname";
}
	?>
<!DOCTYPE html>
<html>
<head>
	<title>
Appointments	</title>
</head>
<body>
<table align="center" border="1px" style="width: 600px; line-height: 40px;">
	<tr>
		<th colspan="8">Appointments</th>
	</tr>

	<t>
		<th>Patient Id</th>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Gender </th>
		<th>Date visit </th>
		<th> Time visit</th>
		<th> Telephone Number</th>
		<th> Email Address</th>
	</t>
	<tr>
	<td><?php echo $rows['patientID']; ?></td>
		<td><?php echo $rows['firstname']; ?></td>
				<td><?php echo $rows['lastname']; ?></td>
		<td><?php echo $rows['gender']; ?></td>
		<td><?php echo $rows['date']; ?></td>
		<td><?php echo $rows['time']; ?></td>
		<td><?php echo $rows['telephone']; ?></td>
		<td><?php echo $rows['email']; ?></td>
</tr>
</table>
</body>
</html>